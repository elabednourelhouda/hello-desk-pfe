<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\Auth\PasswordController;
use App\Http\Controllers\Admin\DashboardController as AdminDashboardController;
use App\Http\Controllers\Admin\SpaceController as AdminSpaceController;
use App\Http\Controllers\Admin\ProspectController as AdminProspectController;
use App\Http\Controllers\Admin\ClientController as AdminClientController;
use App\Http\Controllers\Commercial\DashboardController as CommercialDashboardController;
use App\Http\Controllers\Client\DashboardController as ClientDashboardController;

Route::get('/', function () {
    return view('welcome');
})->name('home');

/*
|--------------------------------------------------------------------------
| Auth routes
|--------------------------------------------------------------------------
*/

Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
Route::post('/login', [AuthController::class, 'login'])->name('login.post');

Route::get('/signin', function () {
    return redirect()->route('login');
})->name('signin');

Route::post('/logout', [AuthController::class, 'logout'])
    ->middleware('auth')
    ->name('logout');
Route::get('/spaces', [AdminSpaceController::class, 'index'])->name('spaces.index');

Route::middleware('auth')->group(function () {
    Route::get('/password/change', [PasswordController::class, 'edit'])->name('password.change');
    Route::put('/password/change', [PasswordController::class, 'update'])->name('password.update');
});

/*
|--------------------------------------------------------------------------
| Dashboards
|--------------------------------------------------------------------------
*/

Route::middleware(['auth', 'password.changed', 'role:admin'])
    ->prefix('admin')
    ->name('admin.')
    ->group(function () {
        Route::get('/dashboard', [AdminDashboardController::class, 'index'])->name('dashboard');

        Route::get('/spaces', [AdminSpaceController::class, 'index'])->name('spaces.index');
        Route::get('/map', [AdminSpaceController::class, 'map'])->name('map.index');

        Route::resource('prospects', AdminProspectController::class)
            ->only(['index', 'create', 'store', 'show', 'edit', 'update']);

        Route::post('/prospects/{prospect}/convert', [AdminProspectController::class, 'convert'])
            ->name('prospects.convert');

        Route::patch('/prospects/{prospect}/mark-lost', [AdminProspectController::class, 'markLost'])
            ->name('prospects.markLost');

        Route::patch('/prospects/{prospect}/reactivate', [AdminProspectController::class, 'reactivate'])
            ->name('prospects.reactivate');

        Route::get('/clients', [AdminClientController::class, 'index'])->name('clients.index');
        Route::get('/clients/{client}/edit', [AdminClientController::class, 'edit'])->name('clients.edit');
        Route::put('/clients/{client}', [AdminClientController::class, 'update'])->name('clients.update');

        Route::get('/clients/create', [AdminClientController::class, 'create'])
        ->name('clients.create');

        Route::post('/clients', [AdminClientController::class, 'store'])
            ->name('clients.store');

        Route::get('/clients/{client}', [AdminClientController::class, 'show'])->name('clients.show');

        Route::patch('/clients/{client}/deactivate', [AdminClientController::class, 'deactivate'])
            ->name('clients.deactivate');

        Route::patch('/clients/{client}/reactivate', [AdminClientController::class, 'reactivate'])
            ->name('clients.reactivate');

        Route::patch('/clients/{client}/reset-password', [AdminClientController::class, 'resetPassword'])
            ->name('clients.resetPassword');
    });

Route::middleware(['auth', 'password.changed', 'role:commercial'])
    ->prefix('commercial')
    ->name('commercial.')
    ->group(function () {
        Route::get('/dashboard', [CommercialDashboardController::class, 'index'])->name('dashboard');
    });

Route::middleware(['auth', 'role:client', 'client.active', 'password.changed'])
    ->prefix('client')
    ->name('client.')
    ->group(function () {
        Route::get('/dashboard', [ClientDashboardController::class, 'index'])->name('dashboard');
    });