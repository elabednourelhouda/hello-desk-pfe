<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Space extends Model
{
    protected $fillable = [
        'campus_id',
        'floor_id',
        'space_type_id',
        'name',
        'internal_code',
        'capacity',
        'area_m2',
        'price_per_hour',
        'price_per_day',
        'price_per_month',
        'status',
        'description',
        'internal_notes',
        'map_x',
        'map_y',
        'map_width',
        'map_height',
        'is_active',
    ];

    public function campus()
    {
        return $this->belongsTo(Campus::class);
    }

    public function floor()
    {
        return $this->belongsTo(Floor::class);
    }

    public function spaceType()
    {
        return $this->belongsTo(SpaceType::class);
    }

    public function accessories()
    {
        return $this->belongsToMany(Accessory::class, 'accessory_space')
            ->withTimestamps();
    }
}