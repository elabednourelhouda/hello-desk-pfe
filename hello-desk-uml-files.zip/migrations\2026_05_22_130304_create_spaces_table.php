<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('spaces', function (Blueprint $table) {
            $table->id();

            $table->foreignId('campus_id')
                ->constrained('campuses')
                ->restrictOnDelete();

            $table->foreignId('floor_id')
                ->constrained('floors')
                ->restrictOnDelete();

            $table->foreignId('space_type_id')
                ->constrained('space_types')
                ->restrictOnDelete();

            $table->string('name');
            $table->string('internal_code')->nullable()->unique();

            $table->integer('capacity')->nullable();
            $table->decimal('area_m2', 8, 2)->nullable();

            $table->decimal('price_per_hour', 10, 2)->nullable();
            $table->decimal('price_per_day', 10, 2)->nullable();
            $table->decimal('price_per_month', 10, 2)->nullable();

            $table->string('status')->default('available');
            $table->text('description')->nullable();
            $table->text('internal_notes')->nullable();

            $table->integer('map_x')->nullable();
            $table->integer('map_y')->nullable();
            $table->integer('map_width')->nullable();
            $table->integer('map_height')->nullable();

            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('spaces');
    }
};
