<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Prospect extends Model
{
    protected $fillable = [
        'full_name',
        'phone',
        'email',
        'company_name',
        'registered_at',
        'need',
        'preferred_campus_id',
        'preferred_space_type_id',
        'budget',
        'source',
        'crm_status',
        'notes',
        'assigned_to',
        'converted_client_id',
        'converted_at',
    ];

    protected $casts = [
        'registered_at' => 'date',
        'converted_at' => 'datetime',
    ];
    public function preferredCampus()
    {
        return $this->belongsTo(Campus::class, 'preferred_campus_id');
    }

    public function preferredSpaceType()
    {
        return $this->belongsTo(SpaceType::class, 'preferred_space_type_id');
    }

    public function assignedCommercial()
    {
        return $this->belongsTo(User::class, 'assigned_to');
    }

    public function convertedClient()
    {
        return $this->belongsTo(User::class, 'converted_client_id');
    }
}